import {Navbar} from "../components/navbar.js";

export const Aiquiz = () => {
    return (<div>
        <Navbar />
        Aiquiz
        
        </div>);
};